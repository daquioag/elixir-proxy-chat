Tab 1:
iex.bat .\echo.ex
EchoServerActive.start

Tab2:
 javac EchoClient.java
java EchoClient